  let navBtn = $('.nav-item');

  let carrossel = $('.carousel-inner');
  let principal = $('#titulo-principal');
  let secundario = $('#titulo-secundario');

  let scrollTo = '';

  $(navBtn).click(function() {

    let btnId = $(this).attr('id');

    if(btnId == 'about-sobre') {
      scrollTo = principal;
    } else if(btnId == 'about-alguns') {
      scrollTo = secundario;
    } else if(btnId == 'team-menu') {
      scrollTo = teamSection;
    } else if(btnId == 'portfolio-menu') {
      scrollTo = portfolioSection;
    } else if(btnId == 'contact-menu') {
      scrollTo = contactSection;
    } else {
      scrollTo = carrossel;
    }

    $([document.documentElement, document.body]).animate({
        scrollTop: $(scrollTo).offset().top - 70
    }, 1500);
  });